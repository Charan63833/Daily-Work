export class Employee {
    id:number;
    password:string;
    name:string;
    address:string;
    age:number;
    company:string;
}