export class User {
     
    id:number;
    username:string;
    password:string;
    address:string;
    phoneNo:number

}