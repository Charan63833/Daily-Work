import { Employee } from "./model/employee";

export const EMPLOYEES: Employee[] = [

    {id:100,password:"password",name:"Charan",address:"Nellore",age:23,company:"Cognizant"},
    {id:101,password:"password",name:"Ram",address:"Nellore",age:22,company:"TCS"},
    {id:102,password:"password",name:"Ravi",address:"Guntur",age:24,company:"Cognizant"},
    {id:103,password:"password",name:"Naresh",address:"Vijayawada",age:23,company:"Wipro"},
    {id:104,password:"password",name:"Harish",address:"Vizag",age:23,company:"Cognizant"}
];